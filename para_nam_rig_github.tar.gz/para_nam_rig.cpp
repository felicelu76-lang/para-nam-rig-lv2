#include <cmath>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <span>
#include <memory>
#include <fstream>
#include <filesystem>
#include <algorithm>
#include <zip.h>

#include <lv2/core/lv2.h>
#include <lv2/atom/atom.h>
#include <lv2/atom/util.h>
#include <lv2/atom/forge.h>
#include <lv2/urid/urid.h>
#include <lv2/patch/patch.h>
#include <lv2/state/state.h>
#include <lv2/worker/worker.h>

#include <nlohmann/json.hpp>
#include "DSP/NamModelEngine.h"

#define PLUGIN_URI "https://github.com/felicelu76-lang/para-nam-rig-lv2"
#define MODEL_URI  "https://github.com/felicelu76-lang/para-nam-rig-lv2#model"

static constexpr int DEFAULT_MAX_FRAMES = 4096;

using namparametric::dsp::NamModelEngine;
using namparametric::dsp::ModelSize;
using namparametric::dsp::OutputMode;
using namparametric::dsp::ModelParameterInfo;

struct Biquad {
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
    double z1 = 0.0, z2 = 0.0;

    inline float process(float x) {
        double in = static_cast<double>(x);
        double out = b0 * in + z1;
        z1 = b1 * in - a1 * out + z2;
        z2 = b2 * in - a2 * out;
        return static_cast<float>(out);
    }

    void setHighPass(double fs, double f0, double Q) {
        double w0 = 2.0 * M_PI * f0 / fs;
        double cosw0 = std::cos(w0);
        double alpha = std::sin(w0) / (2.0 * Q);
        double a0 = 1.0 + alpha;
        b0 = ((1.0 + cosw0) / 2.0) / a0;
        b1 = (-(1.0 + cosw0)) / a0;
        b2 = ((1.0 + cosw0) / 2.0) / a0;
        a1 = (-2.0 * cosw0) / a0;
        a2 = (1.0 - alpha) / a0;
    }

    void setLowPass(double fs, double f0, double Q) {
        double w0 = 2.0 * M_PI * f0 / fs;
        double cosw0 = std::cos(w0);
        double alpha = std::sin(w0) / (2.0 * Q);
        double a0 = 1.0 + alpha;
        b0 = ((1.0 - cosw0) / 2.0) / a0;
        b1 = (1.0 - cosw0) / a0;
        b2 = ((1.0 - cosw0) / 2.0) / a0;
        a1 = (-2.0 * cosw0) / a0;
        a2 = (1.0 - alpha) / a0;
    }

    void setPeaking(double fs, double f0, double Q, double gainDb) {
        double A = std::pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * M_PI * f0 / fs;
        double cosw0 = std::cos(w0);
        double alpha = std::sin(w0) / (2.0 * Q);
        double a0 = 1.0 + alpha / A;
        b0 = (1.0 + alpha * A) / a0;
        b1 = (-2.0 * cosw0) / a0;
        b2 = (1.0 - alpha * A) / a0;
        a1 = (-2.0 * cosw0) / a0;
        a2 = (1.0 - alpha / A) / a0;
    }
};

struct PowerSagCompressor {
    double envDb = -90.0;
    double alphaAttack = 0.0;
    double alphaRelease = 0.0;

    void init(double fs) {
        alphaAttack  = std::exp(-1.0 / (0.022 * fs)); // 22 ms
        alphaRelease = std::exp(-1.0 / (0.140 * fs)); // 140 ms
        envDb = -90.0;
    }

    inline float process(float x, float threshDb) {
        double absX = std::fabs(static_cast<double>(x)) + 1e-9;
        double inDb = 20.0 * std::log10(absX);

        if (inDb > envDb)
            envDb = alphaAttack * envDb + (1.0 - alphaAttack) * inDb;
        else
            envDb = alphaRelease * envDb + (1.0 - alphaRelease) * inDb;

        const double ratio = 1.8;
        const double kneeWidth = 6.0;
        const double makeupDb = 1.0;

        double over = envDb - static_cast<double>(threshDb);
        double gainRedDb = 0.0;

        if (2.0 * over < -kneeWidth) {
            gainRedDb = 0.0;
        } else if (2.0 * std::fabs(over) <= kneeWidth) {
            double temp = over + kneeWidth / 2.0;
            gainRedDb = ((1.0 / ratio) - 1.0) * (temp * temp) / (2.0 * kneeWidth);
        } else {
            gainRedDb = ((1.0 / ratio) - 1.0) * over;
        }

        double totalGain = std::pow(10.0, (gainRedDb + makeupDb) / 20.0);
        return static_cast<float>(x * totalGain);
    }
};

enum PortIndex {
    PORT_CONTROL = 0,
    PORT_NOTIFY = 1,
    PORT_IN = 2,
    PORT_OUT = 3,
    PORT_PRE_ON = 4,
    PORT_PRE_MID = 5,
    PORT_IN_DB = 6,
    PORT_GATE_DB = 7,
    PORT_OUT_DB = 8,
    PORT_IN_CAL_MODE = 9,
    PORT_CAL_DBU = 10,
    PORT_OUT_CAL_MODE = 11,
    PORT_MODEL_SIZE = 12,
    PORT_K1 = 13,
    PORT_LED1 = 14,
    PORT_K2 = 15,
    PORT_LED2 = 16,
    PORT_K3 = 17,
    PORT_LED3 = 18,
    PORT_K4 = 19,
    PORT_LED4 = 20,
    PORT_K5 = 21,
    PORT_LED5 = 22,
    PORT_K6 = 23,
    PORT_LED6 = 24,
    PORT_SW1 = 25,
    PORT_LED7 = 26,
    PORT_SW2 = 27,
    PORT_LED8 = 28,
    PORT_SAG_ON = 29,
    PORT_SAG_THR = 30,
    PORT_CAB_DYN = 31,
    PORT_DEPTH_DB = 32,
    PORT_CUT_3K8 = 33,
    TOTAL_PORTS = 34
};

static constexpr int LED_PORTS[8] = {
    PORT_LED1, PORT_LED2, PORT_LED3, PORT_LED4,
    PORT_LED5, PORT_LED6, PORT_LED7, PORT_LED8
};

struct ModelLoadMessage {
    LV2_Atom atom;
    char path[1024];
    int sizeMode;
};

struct ModelSwapMessage {
    LV2_Atom atom;
    NamModelEngine* engine;
    bool metadataHasCab;
    int statusEnum;
    bool ledActive[8];
    int paramToSlot[8];
    char loadedPath[1024];
};

struct ParaNamPlugin {
    double sampleRate = 48000.0;
    LV2_URID_Map* map = nullptr;
    LV2_Worker_Schedule* schedule = nullptr;
    LV2_Atom_Forge forge;

    struct URIs {
        LV2_URID atom_Path;
        LV2_URID atom_URID;
        LV2_URID patch_Set;
        LV2_URID patch_Get;
        LV2_URID patch_property;
        LV2_URID patch_value;
        LV2_URID model_Path;
        LV2_URID cmd_load;
        LV2_URID cmd_swap;
    } uris;

    const LV2_Atom_Sequence* control_port = nullptr;
    LV2_Atom_Sequence* notify_port = nullptr;
    const float* in_port = nullptr;
    float* out_port = nullptr;
    const float* in_params[TOTAL_PORTS] = {nullptr};
    float* out_params[TOTAL_PORTS] = {nullptr};

    Biquad preHpf, preLpf, preMid;
    Biquad postHpf, postDepth, postDeharsh, postLpf;
    PowerSagCompressor sagComp;
    double gateEnv = 0.0;

    float lastPreMidDb = -999.0f;
    float lastPostDepthDb = -999.0f;
    float lastPostDeharshDb = -999.0f;
    int lastSizeMode = 0;

    std::unique_ptr<NamModelEngine> activeEngine;
    std::vector<ModelParameterInfo> paramInfos;
    std::vector<float> paramValues;
    int paramToSlot[8] = {-1, -1, -1, -1, -1, -1, -1, -1};

    bool currentModelHasCab = true;
    int statusEnum = 0;
    bool ledActive[8] = {false, false, false, false, false, false, false, false};
    std::string currentModelPath = "";
    bool needNotifyPath = false;

    std::vector<float> audioBuf;

    void initFilters() {
        preHpf.setHighPass(sampleRate, 85.0, 0.7071);
        preLpf.setLowPass(sampleRate, 11500.0, 0.7071);
        preMid.setPeaking(sampleRate, 1100.0, 0.7, 1.5);

        postHpf.setHighPass(sampleRate, 90.0, 0.7071);
        postDepth.setPeaking(sampleRate, 118.0, 1.2, 1.8);
        postDeharsh.setPeaking(sampleRate, 3800.0, 2.5, -1.5);
        postLpf.setLowPass(sampleRate, 7200.0, 0.7071);

        sagComp.init(sampleRate);
    }
};

static std::string extractIfZip(const std::string& path, bool& outHasCab) {
    outHasCab = false;
    std::string targetPath = path;

    std::ifstream f(path, std::ios::binary);
    if (!f.is_open()) return path;
    char magic[4] = {0};
    f.read(magic, 4);
    f.close();

    if (magic[0] == 'P' && magic[1] == 'K' && magic[2] == 3 && magic[3] == 4) {
        int err = 0;
        zip_t* za = zip_open(path.c_str(), ZIP_RDONLY, &err);
        if (za) {
            zip_int64_t numEntries = zip_get_num_entries(za, 0);
            for (zip_int64_t i = 0; i < numEntries; ++i) {
                const char* name = zip_get_name(za, i, 0);
                if (!name) continue;
                std::string sname(name);
                if (sname.find(".nam") != std::string::npos ||
                    sname.find(".json") != std::string::npos ||
                    sname.find(".pnam") != std::string::npos ||
                    numEntries == 1) {
                    struct zip_stat st;
                    zip_stat_init(&st);
                    zip_stat_index(za, i, 0, &st);
                    zip_file_t* zf = zip_fopen_index(za, i, 0);
                    if (zf) {
                        std::string out(st.size, '\0');
                        zip_fread(zf, out.data(), st.size);
                        zip_fclose(zf);
                        targetPath = "/tmp/paranam_unzipped.nam";
                        std::ofstream of(targetPath, std::ios::binary);
                        of.write(out.data(), out.size());
                        of.close();
                        break;
                    }
                }
            }
            zip_close(za);
        }
    }

    try {
        std::ifstream jf(targetPath);
        nlohmann::json j;
        jf >> j;
        if (j.contains("metadata") && j["metadata"].is_object()) {
            auto& m = j["metadata"];
            if (m.contains("has_cab") && m["has_cab"].is_boolean())
                outHasCab = m["has_cab"].get<bool>();
            else if (m.contains("cab") && m["cab"].is_string() && !m["cab"].get<std::string>().empty())
                outHasCab = true;
            else if (m.contains("gear_type") && m["gear_type"].is_string()) {
                std::string gt = m["gear_type"].get<std::string>();
                if (gt == "full_rig" || gt == "amp_cab") outHasCab = true;
            }
        }
    } catch (...) {}

    return targetPath;
}

static void sendPathConfirmationToUI(ParaNamPlugin* self) {
    if (!self->notify_port || self->currentModelPath.empty()) return;
    const uint32_t capacity = self->notify_port->atom.size;
    lv2_atom_forge_set_buffer(&self->forge, reinterpret_cast<uint8_t*>(self->notify_port), capacity);

    LV2_Atom_Forge_Frame seqFrame;
    lv2_atom_forge_sequence_head(&self->forge, &seqFrame, 0);

    LV2_Atom_Forge_Frame objFrame;
    lv2_atom_forge_frame_time(&self->forge, 0);
    lv2_atom_forge_object(&self->forge, &objFrame, 0, self->uris.patch_Set);
    lv2_atom_forge_key(&self->forge, self->uris.patch_property);
    lv2_atom_forge_urid(&self->forge, self->uris.model_Path);
    lv2_atom_forge_key(&self->forge, self->uris.patch_value);
    lv2_atom_forge_path(&self->forge, self->currentModelPath.c_str(), self->currentModelPath.size());
    lv2_atom_forge_pop(&self->forge, &objFrame);

    lv2_atom_forge_pop(&self->forge, &seqFrame);
}

static LV2_Handle instantiate(const LV2_Descriptor*, double rate, const char*, const LV2_Feature* const* features) {
    auto* self = new ParaNamPlugin();
    self->sampleRate = rate;
    self->audioBuf.assign(DEFAULT_MAX_FRAMES, 0.0f);

    for (int i = 0; features[i]; ++i) {
        if (!std::strcmp(features[i]->URI, LV2_URID__map))
            self->map = static_cast<LV2_URID_Map*>(features[i]->data);
        else if (!std::strcmp(features[i]->URI, LV2_WORKER__schedule))
            self->schedule = static_cast<LV2_Worker_Schedule*>(features[i]->data);
    }

    if (!self->map || !self->schedule) {
        delete self;
        return nullptr;
    }

    lv2_atom_forge_init(&self->forge, self->map);
    self->uris.atom_Path      = self->map->map(self->map->handle, LV2_ATOM__Path);
    self->uris.atom_URID      = self->map->map(self->map->handle, LV2_ATOM__URID);
    self->uris.patch_Set      = self->map->map(self->map->handle, LV2_PATCH__Set);
    self->uris.patch_Get      = self->map->map(self->map->handle, LV2_PATCH__Get);
    self->uris.patch_property = self->map->map(self->map->handle, LV2_PATCH__property);
    self->uris.patch_value    = self->map->map(self->map->handle, LV2_PATCH__value);
    self->uris.model_Path     = self->map->map(self->map->handle, MODEL_URI);
    self->uris.cmd_load       = self->map->map(self->map->handle, PLUGIN_URI "#load");
    self->uris.cmd_swap       = self->map->map(self->map->handle, PLUGIN_URI "#swap");

    self->initFilters();
    return static_cast<LV2_Handle>(self);
}

static void connect_port(LV2_Handle instance, uint32_t port, void* data) {
    auto* self = static_cast<ParaNamPlugin*>(instance);
    switch (port) {
        case PORT_CONTROL: self->control_port = static_cast<const LV2_Atom_Sequence*>(data); break;
        case PORT_NOTIFY:  self->notify_port  = static_cast<LV2_Atom_Sequence*>(data); break;
        case PORT_IN:      self->in_port      = static_cast<const float*>(data); break;
        case PORT_OUT:     self->out_port     = static_cast<float*>(data); break;
        default:
            if (port < TOTAL_PORTS) {
                self->in_params[port]  = static_cast<const float*>(data);
                self->out_params[port] = static_cast<float*>(data);
            }
            break;
    }
}

static void run(LV2_Handle instance, uint32_t n_samples) {
    auto* self = static_cast<ParaNamPlugin*>(instance);

    const int sizeMode = static_cast<int>(std::round(*self->in_params[PORT_MODEL_SIZE]));

    if (self->control_port) {
        LV2_ATOM_SEQUENCE_FOREACH(self->control_port, ev) {
            if (lv2_atom_forge_is_object_type(&self->forge, ev->body.type)) {
                const LV2_Atom_Object* obj = reinterpret_cast<const LV2_Atom_Object*>(&ev->body);
                if (obj->body.otype == self->uris.patch_Set) {
                    const LV2_Atom* property = nullptr;
                    const LV2_Atom* value = nullptr;
                    lv2_atom_object_get(obj,
                        self->uris.patch_property, &property,
                        self->uris.patch_value, &value, 0);
                    if (property && value &&
                        property->type == self->uris.atom_URID &&
                        reinterpret_cast<const LV2_Atom_URID*>(property)->body == self->uris.model_Path &&
                        value->type == self->uris.atom_Path) {
                        const char* path = reinterpret_cast<const char*>(value + 1);
                        ModelLoadMessage msg{};
                        msg.atom.type = self->uris.cmd_load;
                        msg.atom.size = sizeof(ModelLoadMessage) - sizeof(LV2_Atom);
                        std::strncpy(msg.path, path, sizeof(msg.path) - 1);
                        msg.sizeMode = sizeMode;
                        self->lastSizeMode = sizeMode;
                        self->schedule->schedule_work(self->schedule->handle, sizeof(msg), &msg);
                    }
                } else if (obj->body.otype == self->uris.patch_Get) {
                    self->needNotifyPath = true;
                }
            }
        }
    }

    if (sizeMode != self->lastSizeMode && !self->currentModelPath.empty()) {
        self->lastSizeMode = sizeMode;
        ModelLoadMessage msg{};
        msg.atom.type = self->uris.cmd_load;
        msg.atom.size = sizeof(ModelLoadMessage) - sizeof(LV2_Atom);
        std::strncpy(msg.path, self->currentModelPath.c_str(), sizeof(msg.path) - 1);
        msg.sizeMode = sizeMode;
        self->schedule->schedule_work(self->schedule->handle, sizeof(msg), &msg);
    }

    if (self->needNotifyPath && self->notify_port) {
        sendPathConfirmationToUI(self);
        self->needNotifyPath = false;
    }

    for (int i = 0; i < 8; ++i) {
        if (self->out_params[LED_PORTS[i]])
            *self->out_params[LED_PORTS[i]] = self->ledActive[i] ? 1.0f : 0.0f;
    }

    float preMidDb = *self->in_params[PORT_PRE_MID];
    if (std::fabs(preMidDb - self->lastPreMidDb) > 0.01f) {
        self->preMid.setPeaking(self->sampleRate, 1100.0, 0.7, preMidDb);
        self->lastPreMidDb = preMidDb;
    }

    // Depth 0..10 -> -6.0..+6.0 dB (5.0 = 0 dB, default 6.5 = +1.8 dB)
    float postDepthDb = ((*self->in_params[PORT_DEPTH_DB]) - 5.0f) * 1.2f;
    if (std::fabs(postDepthDb - self->lastPostDepthDb) > 0.01f) {
        self->postDepth.setPeaking(self->sampleRate, 118.0, 1.2, postDepthDb);
        self->lastPostDepthDb = postDepthDb;
    }

    // Presence 0..10 -> -5.0..+5.0 dB a 3.8 kHz (5.0 = 0 dB, default 3.5 = -1.5 dB)
    float postDeharshDb = ((*self->in_params[PORT_CUT_3K8]) - 5.0f) * 1.0f;
    if (std::fabs(postDeharshDb - self->lastPostDeharshDb) > 0.01f) {
        self->postDeharsh.setPeaking(self->sampleRate, 3800.0, 2.5, postDeharshDb);
        self->lastPostDeharshDb = postDeharshDb;
    }

    const bool preOn      = (*self->in_params[PORT_PRE_ON] > 0.5f);
    const bool sagOn      = (*self->in_params[PORT_SAG_ON] > 0.5f);
    // Sag 0..10 -> Soglia da -10.0 dB (0) a -28.0 dB (10) (default 4.0 = -17.2 dB)
    const float sagThresh = -10.0f - ((*self->in_params[PORT_SAG_THR]) * 1.8f);
    const int cabMode     = static_cast<int>(std::round(*self->in_params[PORT_CAB_DYN]));
    const bool postCabActive = (cabMode == 1) ? true : ((cabMode == 2) ? self->currentModelHasCab : false);

    float inDbTotal  = *self->in_params[PORT_IN_DB];
    float outDbTotal = *self->in_params[PORT_OUT_DB];

    const bool inCalEnabled = (*self->in_params[PORT_IN_CAL_MODE] > 0.5f);
    const double userDbu    = static_cast<double>(*self->in_params[PORT_CAL_DBU]);
    const int outCalIdx     = std::clamp(static_cast<int>(std::round(*self->in_params[PORT_OUT_CAL_MODE])), 0, 3);
    const OutputMode outMode = (outCalIdx == 0) ? OutputMode::Raw :
                               (outCalIdx == 1) ? OutputMode::Normalized :
                               (outCalIdx == 2) ? OutputMode::Calibrated : OutputMode::Auto;

    if (self->activeEngine && self->activeEngine->IsLoaded()) {
        inDbTotal  += static_cast<float>(self->activeEngine->GetInputCalibrationGainDb(userDbu, inCalEnabled));
        outDbTotal += static_cast<float>(self->activeEngine->GetOutputCalibrationGainDb(userDbu, outMode));
    }

    const float inGainLinear  = std::pow(10.0f, inDbTotal / 20.0f);
    const float outGainLinear = std::pow(10.0f, outDbTotal / 20.0f);
    const float gateThreshLin = std::pow(10.0f, (*self->in_params[PORT_GATE_DB]) / 20.0f);

    if (n_samples > self->audioBuf.size()) {
        self->audioBuf.resize(n_samples, 0.0f);
    }

    // Blocco 1: Pre-Filter Morning Glory + Gate + Input Gain/Calibration
    for (uint32_t i = 0; i < n_samples; ++i) {
        float x = self->in_port[i];
        if (preOn) {
            x = self->preHpf.process(x);
            x = self->preLpf.process(x);
            x = self->preMid.process(x);
        }

        double absIn = std::fabs(x);
        self->gateEnv = 0.995 * self->gateEnv + 0.005 * absIn;
        float gateGain = (self->gateEnv < gateThreshLin)
                         ? static_cast<float>(self->gateEnv / (gateThreshLin + 1e-9))
                         : 1.0f;

        self->audioBuf[i] = x * gateGain * inGainLinear;
    }

    // Blocco 2: Motore Ufficiale NamModelEngine (gestisce sia NAM statici sia ParaNAM + OutputGainCurve)
    if (self->activeEngine && self->activeEngine->IsLoaded()) {
        if (!self->paramValues.empty()) {
            const float slotRaw[8] = {
                *self->in_params[PORT_K1] / 10.0f,
                *self->in_params[PORT_K2] / 10.0f,
                *self->in_params[PORT_K3] / 10.0f,
                *self->in_params[PORT_K4] / 10.0f,
                *self->in_params[PORT_K5] / 10.0f,
                *self->in_params[PORT_K6] / 10.0f,
                *self->in_params[PORT_SW1],
                *self->in_params[PORT_SW2]
            };

            size_t pCount = std::min(self->paramValues.size(), size_t(8));
            for (size_t p = 0; p < pCount; ++p) {
                int slot = self->paramToSlot[p];
                if (slot >= 0 && slot < 8 && p < self->paramInfos.size()) {
                    const auto& info = self->paramInfos[p];
                    if (info.IsSwitch()) {
                        int idx = std::clamp(static_cast<int>(std::round(slotRaw[slot])), 0, static_cast<int>(info.enumValues.size()) - 1);
                        self->paramValues[p] = static_cast<float>(info.enumValues[idx]);
                    } else {
                        self->paramValues[p] = info.minValue + slotRaw[slot] * (info.maxValue - info.minValue);
                    }
                }
            }
            self->activeEngine->SetParameterValues(std::span<const float>(self->paramValues.data(), self->paramValues.size()));
        }

        self->activeEngine->Process(self->audioBuf.data(), self->audioBuf.data(), static_cast<int>(n_samples));
    }

    // Blocco 3 (Power-Amp Sag) + Blocco 5 (Cab Dynamic Post-EQ)
    for (uint32_t i = 0; i < n_samples; ++i) {
        float y = self->audioBuf[i] * outGainLinear;

        if (sagOn) {
            y = self->sagComp.process(y, sagThresh);
        }

        if (postCabActive) {
            y = self->postHpf.process(y);
            y = self->postDepth.process(y);
            y = self->postDeharsh.process(y);
            y = self->postLpf.process(y);
        }

        self->out_port[i] = y;
    }
}

static LV2_Worker_Status work(LV2_Handle instance, LV2_Worker_Respond_Function respond, LV2_Worker_Respond_Handle handle, uint32_t, const void* data) {
    auto* self = static_cast<ParaNamPlugin*>(instance);
    const auto* atom = static_cast<const LV2_Atom*>(data);

    if (atom->type == self->uris.cmd_load) {
        const auto* msg = static_cast<const ModelLoadMessage*>(data);
        std::string rawPath(msg->path);
        ModelSize desiredSize = (msg->sizeMode == 1) ? ModelSize::Lite : ModelSize::Full;

        bool hasCab = false;
        std::string loadablePath = extractIfZip(rawPath, hasCab);

        ModelSwapMessage reply{};
        reply.atom.type = self->uris.cmd_swap;
        reply.atom.size = sizeof(ModelSwapMessage) - sizeof(LV2_Atom);
        std::strncpy(reply.loadedPath, rawPath.c_str(), sizeof(reply.loadedPath) - 1);
        for (int i = 0; i < 8; ++i) {
            reply.ledActive[i] = false;
            reply.paramToSlot[i] = -1;
        }

        auto newEngine = std::make_unique<NamModelEngine>();
        std::string errMsg;
        if (newEngine->LoadModel(loadablePath, errMsg, desiredSize)) {
            newEngine->Reset(self->sampleRate, DEFAULT_MAX_FRAMES);

            const auto& infos = newEngine->GetParameterInfos();
            int knobCursor = 0;
            int swCursor = 6;
            std::string mapLog = std::filesystem::path(rawPath).filename().string() + " -> ";

            for (size_t p = 0; p < infos.size() && p < 8; ++p) {
                if (infos[p].IsSwitch() && swCursor < 8) {
                    reply.paramToSlot[p] = swCursor;
                    reply.ledActive[swCursor] = true;
                    mapLog += "Sw" + std::to_string(swCursor - 5) + ":" + infos[p].name + " ";
                    swCursor++;
                } else if (knobCursor < 6) {
                    reply.paramToSlot[p] = knobCursor;
                    reply.ledActive[knobCursor] = true;
                    mapLog += "K" + std::to_string(knobCursor + 1) + ":" + infos[p].name + " ";
                    knobCursor++;
                }
            }

            int totalActive = static_cast<int>(infos.size());
            if (totalActive == 0) {
                reply.statusEnum = 1; // Static
                mapLog += "Static NAM";
            } else if (totalActive <= 6) {
                reply.statusEnum = 1 + totalActive; // Para 1..6
            } else {
                reply.statusEnum = 8; // Para 7+
            }

            std::ofstream infoFile("/var/pipedal/audio_uploads/NeuralAmpModels/_ACTIVE_MODEL_INFO.txt");
            if (infoFile.is_open()) {
                infoFile << mapLog << " | CabMeta:" << (hasCab ? "YES" : "NO") << "\n";
            }

            reply.engine = newEngine.release();
            reply.metadataHasCab = hasCab;
            respond(handle, sizeof(reply), &reply);
        } else {
            fprintf(stderr, "[ParaNAM] NamModelEngine LoadModel fallito per %s: %s\n", rawPath.c_str(), errMsg.c_str());
            reply.engine = nullptr;
            reply.statusEnum = 9; // Error
            respond(handle, sizeof(reply), &reply);
        }
    }
    return LV2_WORKER_SUCCESS;
}

static LV2_Worker_Status work_response(LV2_Handle instance, uint32_t, const void* data) {
    auto* self = static_cast<ParaNamPlugin*>(instance);
    const auto* atom = static_cast<const LV2_Atom*>(data);
    if (atom->type == self->uris.cmd_swap) {
        const auto* reply = static_cast<const ModelSwapMessage*>(data);
        if (reply->engine) {
            self->activeEngine.reset(reply->engine);
            self->paramInfos  = self->activeEngine->GetParameterInfos();
            self->paramValues = self->activeEngine->GetParameterValues();
            self->currentModelHasCab = reply->metadataHasCab;
        }
        self->statusEnum = reply->statusEnum;
        for (int i = 0; i < 8; ++i) {
            self->ledActive[i]   = reply->ledActive[i];
            self->paramToSlot[i] = reply->paramToSlot[i];
        }
        self->currentModelPath = reply->loadedPath;
        self->needNotifyPath = true;
    }
    return LV2_WORKER_SUCCESS;
}

static LV2_State_Status save_state(LV2_Handle instance, LV2_State_Store_Function store, LV2_State_Handle handle, uint32_t, const LV2_Feature* const*) {
    auto* self = static_cast<ParaNamPlugin*>(instance);
    if (!self->currentModelPath.empty()) {
        store(handle, self->uris.model_Path,
              self->currentModelPath.c_str(),
              self->currentModelPath.size() + 1,
              self->uris.atom_Path,
              LV2_STATE_IS_POD | LV2_STATE_IS_PORTABLE);
    }
    return LV2_STATE_SUCCESS;
}

static LV2_State_Status restore_state(LV2_Handle instance, LV2_State_Retrieve_Function retrieve, LV2_State_Handle handle, uint32_t, const LV2_Feature* const*) {
    auto* self = static_cast<ParaNamPlugin*>(instance);
    size_t size = 0;
    uint32_t type = 0;
    uint32_t flags = 0;
    const void* value = retrieve(handle, self->uris.model_Path, &size, &type, &flags);
    if (value && size > 0) {
        const char* path = static_cast<const char*>(value);
        ModelLoadMessage msg{};
        msg.atom.type = self->uris.cmd_load;
        msg.atom.size = sizeof(ModelLoadMessage) - sizeof(LV2_Atom);
        std::strncpy(msg.path, path, sizeof(msg.path) - 1);
        msg.sizeMode = self->lastSizeMode;
        self->schedule->schedule_work(self->schedule->handle, sizeof(msg), &msg);
    }
    return LV2_STATE_SUCCESS;
}

static void cleanup(LV2_Handle instance) {
    delete static_cast<ParaNamPlugin*>(instance);
}

static const void* extension_data(const char* uri) {
    static const LV2_Worker_Interface worker = { work, work_response, nullptr };
    static const LV2_State_Interface state   = { save_state, restore_state };
    if (!std::strcmp(uri, LV2_WORKER__interface)) return &worker;
    if (!std::strcmp(uri, LV2_STATE__interface))  return &state;
    return nullptr;
}

static const LV2_Descriptor descriptor = {
    PLUGIN_URI, instantiate, connect_port, nullptr, run, nullptr, cleanup, extension_data
};

LV2_SYMBOL_EXPORT const LV2_Descriptor* lv2_descriptor(uint32_t index) {
    return (index == 0) ? &descriptor : nullptr;
}
