cmake_minimum_required(VERSION 3.22)
project(para_nam_rig LANGUAGES CXX C)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

find_package(PkgConfig REQUIRED)
find_package(Threads REQUIRED)
pkg_check_modules(LIBZIP REQUIRED libzip)

set(DLC_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../NamParametricPlugin")
set(NAM_CORE_DIR "${DLC_ROOT}/external/nam_core_parametric")
set(AUDIO_DSP_TOOLS_DIR "${DLC_ROOT}/external/AudioDSPTools")

file(GLOB_RECURSE NAM_CORE_SOURCES
    "${NAM_CORE_DIR}/NAM/*.cpp"
)

add_library(para_nam_rig SHARED
    para_nam_rig.cpp
    "${DLC_ROOT}/Source/DSP/NamModelEngine.cpp"
    ${NAM_CORE_SOURCES}
)

target_compile_definitions(para_nam_rig PRIVATE
    NDEBUG=1
    EIGEN_NO_DEBUG=1
    EIGEN_DONT_PARALLELIZE=1
    EIGEN_FAST_MATH=1
    NAM_SAMPLE_FLOAT=1
    DSP_SAMPLE_FLOAT=1
    NAM_ENABLE_A2_FAST=1
)

target_include_directories(para_nam_rig PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}"
    "${DLC_ROOT}/Source"
    "${NAM_CORE_DIR}"
    "${NAM_CORE_DIR}/NAM"
    "${NAM_CORE_DIR}/Dependencies/eigen"
    "${NAM_CORE_DIR}/Dependencies/nlohmann"
    "${AUDIO_DSP_TOOLS_DIR}"
    "${AUDIO_DSP_TOOLS_DIR}/dsp"
    ${LIBZIP_INCLUDE_DIRS}
)

target_link_libraries(para_nam_rig PRIVATE
    ${LIBZIP_LIBRARIES}
    Threads::Threads
)

target_compile_options(para_nam_rig PRIVATE
    -O3
    -mcpu=cortex-a76+crypto
    -mtune=cortex-a76
    -ffast-math
    -funroll-loops
    -fomit-frame-pointer
    -flto=auto
    -fsigned-char
    -Wno-deprecated-declarations
    -Wno-changes-meaning
)

target_link_options(para_nam_rig PRIVATE
    -flto=auto
)

set_target_properties(para_nam_rig PROPERTIES PREFIX "")
