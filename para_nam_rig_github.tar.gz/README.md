# ParaNAM Rig Strip LV2 (`para_nam_rig.lv2`)

All-in-one neural guitar channel strip LV2 plugin for **PiPedal 2.0** on **Raspberry Pi 5 (ARM64 / Cortex-A76)**, powered by `NamModelEngine` and `NeuralAmpModelerCoreParametric`.

## Features
- Native playback of **static NAM (A1/A2)** and **parametric NAM / ParaNAM (`.pnam`, `HyperWaveNet`, `HyperA2`, `ParametricSlimmableContainer`)** profiles.
- **Pre & Gain**: 85 Hz HPF + 11.5 kHz LPF anti-aliasing filter, 1.1 kHz Mid Boost (0 dB at noon), Input/Output Gain, Noise Gate.
- **Calibration**: Input dBU calibration, Output Normalization/Calibration, and Full/Lite quality selector.
- **Parametric Controls**: 6 Knobs + 2 Switches with active green status LEDs.
- **Sag & Cab Dynamic**: Tube power-amp sag compressor (22 ms attack / 140 ms release) and post-amp cab shaping (`OFF` / `ON` / `AUTO Meta` with Depth @ 118 Hz and Presence @ 3.8 kHz).
