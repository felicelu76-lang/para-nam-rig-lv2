# ParaNAM Rig Strip LV2 (para_nam_rig.lv2)

**An all-in-one, low-latency neural guitar channel strip LV2 plugin engineered for PiPedal 2.0 on Raspberry Pi 5 (ARM64 / Cortex-A76).**

---

## Why This Project Exists

While neural amp capture engines like **Neural Amp Modeler (NAM)** deliver remarkable realism, running them inside a headless live guitar rig (such as **PiPedal 2.0** on a Raspberry Pi 5 with a Blokas Pisound audio interface) typically presents three practical limitations:

1. **No Native Parametric NAM Support on Headless LV2 Hosts:** Existing LV2 wrappers only run static `.nam` captures (A1/A2). Parametric captures generated with `ParaNAM-Trainer` (`HyperWaveNet`, `HyperA2`, `ParametricSlimmableContainer`, and `.pnam` files with non-linear PCHIP volume curves) are desktop-oriented (VST3/AU/Standalone) and rely on dynamic GUI widgets that headless web UIs cannot expose.
2. **Single-Core CPU Bottlenecks on Heavy Chains:** Running a `Full` resolution NAM A2 model alongside a Cabinet IR convolver and a Convolution Reverb on a single JACK real-time core at 64 samples can push a single ARM core to 80%+ and trigger XRUNs.
3. **Digital Aliasing & Static "Feel" Without Pre/Post Conditioning:** Feeding raw, unconditioned guitar transients directly into a neural network often produces harsh ultrasonic pick aliasing and lacks the natural transformer compression ("power-amp sag") and speaker-cone smoothing found in studio amp suites.

**ParaNAM Rig Strip** solves all three problems by combining the official **`NamModelEngine`** with an **Asynchronous Dual-Core (`Threaded`) Real-Time Processor** (`SCHED_FIFO`), hardware ARM64 Flush-To-Zero (`FPCR`) denormal protection, and a zero-latency analog-inspired pre/post conditioning chain inside a single LV2 bundle.

---

## Signal Flow & Architecture

### 1. Pre-Amp Conditioning & Input Stage (1. Pre & Gain)
* **Pre ON:** Butterworth 12 dB/oct High-Pass @ **85 Hz** (tightens sub-bass before distortion) + Low-Pass @ **11.5 kHz** (strips ultrasonic pick noise to prevent neural aliasing).
* **Mid Boost (-6.0 dB to +6.0 dB, 0 dB at noon, default +1.5 dB):** Wide-Q (0.7) peaking filter centered at **1.1 kHz** for pick focus and elasticity.
* **Input Gain (-15 to +15 dB, default -3.0 dB), Noise Gate (default -72 dB), Output Gain (default +2.5 dB).**

### 2. Calibration, Quality & Dual-Core Offloading (Calibration)
* **Input Calibration (Off / Calibrated) & Value (dBU):** Matches your audio interface headroom (default -6.00 dBU) against the capture's `input_level_dbu` metadata.
* **Output Calibration (Raw / Normalized / Calibrated / Auto):** Automatically levels captures to -18 dBFS (Normalized) or preserves hardware insertion gain (Calibrated).
* **Quality (Full / Lite):** Switches between full and lightweight branches on `ParametricSlimmableContainer`, `HyperA2`, and static `SlimmableContainer` (A2) models.
* **Threaded (ON by default):** Offloads neural network inference to a dedicated high-priority `SCHED_FIFO` background worker thread on a second Raspberry Pi 5 CPU core via lock-free ping-pong buffering, freeing the primary JACK real-time thread for Cabinet IRs and Convolution Reverbs.

### 3. Universal Neural Engine (2. Para Knobs & 3. Switches)
* Loads **static NAM (A1 & A2)** and **parametric .nam / .pnam** captures (`HyperWaveNet`, `ConcatWaveNet`, `ConcatLSTM`, `ParametricSlimmableContainer`), including zipped `.pnam` archives and `linear_volume` PCHIP curves.
* **6 Continuous Knobs (Knob 1 – Knob 6) + 2 Switches (Switch 1 – Switch 2)** with **real-time green status LEDs** indicating which controls are active in the loaded model.

### 4. Power-Amp Sag & Cab Dynamic (4. Sag & Cab Dynamic)
* **Power-Amp Sag (Sag ON + Sag 0–10, default 4.0):** Soft-knee (6 dB), 1.8:1 envelope compressor with **22 ms attack** and **140 ms release** to replicate tube output transformer compression.
* **Cab Dynamic (OFF / ON / AUTO Meta):** Post-amp cabinet shaping with **90 Hz** sub-cut, **Depth (0–10)** resonance @ **118 Hz**, **Presence (0–10)** de-harshing filter @ **3.8 kHz**, and **7.2 kHz** high-cut.

---

## Build & Install on Raspberry Pi 5

 sudo apt update
 sudo apt install -y build-essential cmake ninja-build git lv2-dev nlohmann-json3-dev libzip-dev zlib1g-dev

 git clone [https://github.com/felicelu76-lang/para-nam-rig-lv2.git](https://github.com/felicelu76-lang/para-nam-rig-lv2.git)
 cd para-nam-rig-lv2
 git clone --recursive [https://github.com/DLC86/NamParametricPlugin.git](https://github.com/DLC86/NamParametricPlugin.git) ../NamParametricPlugin
 python3 -c 'import re; p="../NamParametricPlugin/Source/DSP/NamModelEngine.cpp"; open(p,"w").write(re.sub(r"hyper->ConfigureKernelSmoothing\s*\([^;]*\);", "/* bypassed */ ;", open(p).read(), flags=re.DOTALL))'

 cmake -B build -G Ninja
 cmake --build build -j 4

 sudo mkdir -p /usr/lib/lv2/para_nam_rig.lv2
 sudo cp build/para_nam_rig.so manifest.ttl para_nam_rig.ttl /usr/lib/lv2/para_nam_rig.lv2/
 sudo systemctl restart pipedald

---

## Credits & Acknowledgments
* **[The Tone Scientist](https://www.youtube.com/@TheToneScientist)** for pioneering parametric neural captures (`ParaNAM-Trainer`), the `ParametricSlimmableContainer` / `linear_volume` extensions, and community reference models.
* **[DLC86](https://github.com/DLC86/NamParametricPlugin)** & **[Phillip Self](https://github.com/phillipmself/NamParametricPlugin)** for `NamModelEngine`, `OutputGainCurve`, and `NeuralAmpModelerCoreParametric`.
* **[Steven Atkinson](https://github.com/sdatkinson/neural-amp-modeler)** for Neural Amp Modeler.
* **[Robin Davies](https://github.com/rerdavies/pipedal)** for PiPedal 2.0 and its LV2 UI extensions.
